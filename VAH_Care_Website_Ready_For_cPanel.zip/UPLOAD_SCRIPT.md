# 🚀 Quick cPanel Upload Script

## 📋 **Step-by-Step Upload Process:**

### **Step 1: Prepare Files**
1. **Create folders on your computer:**
   ```
   📁 VAH_Care_Upload/
   ├── 📁 public_html/
   │   ├── 📁 images/
   │   └── 📁 backend/
   │       └── 📁 uploads/
   │           └── 📁 resumes/
   ```

### **Step 2: Copy Files**
**Copy these files to `public_html/`:**
- `frontend/index.html` → `public_html/index.html`
- `frontend/jobs.html` → `public_html/jobs.html`
- `frontend/admin-login.html` → `public_html/admin-login.html`
- `frontend/admin-cms.html` → `public_html/admin-cms.html`
- `frontend/demo.html` → `public_html/demo.html`
- `frontend/style.css` → `public_html/style.css`
- `frontend/script.js` → `public_html/script.js`
- `frontend/admin-cms.js` → `public_html/admin-cms.js`

**Copy these files to `public_html/images/`:**
- `frontend/images/logo.png` → `public_html/images/logo.png`
- `frontend/images/hero-banner.png` → `public_html/images/hero-banner.png`

**Copy these files to `public_html/backend/`:**
- `backend/config.php` → `public_html/backend/config.php`
- `backend/admin-login.php` → `public_html/backend/admin-login.php`
- `backend/admin-logout.php` → `public_html/backend/admin-logout.php`
- `backend/check-admin-session.php` → `public_html/backend/check-admin-session.php`
- `backend/cms-api.php` → `public_html/backend/cms-api.php`
- `backend/public-jobs.php` → `public_html/backend/public-jobs.php`
- `backend/submit-contact.php` → `public_html/backend/submit-contact.php`
- `backend/submit-job-application.php` → `public_html/backend/submit-job-application.php`
- `backend/cms-jobs.json` → `public_html/backend/cms-jobs.json`
- `backend/cms-stats.json` → `public_html/backend/cms-stats.json`

**Create empty folder:**
- `public_html/backend/uploads/resumes/` (empty folder)

### **Step 3: Upload to cPanel**
1. **Login to cPanel**
2. **Open File Manager**
3. **Navigate to `public_html/`**
4. **Upload the entire `public_html/` folder contents**

### **Step 4: Set Permissions**
**In cPanel File Manager, right-click each file/folder and set permissions:**

**Files (644):**
- All `.html` files
- All `.css` files  
- All `.js` files
- All `.php` files

**Directories (755):**
- `backend/`
- `images/`
- `backend/uploads/`
- `backend/uploads/resumes/`

**Writable Files (666):**
- `backend/cms-jobs.json`
- `backend/cms-stats.json`

### **Step 5: Test Everything**
**Visit these URLs to test:**
- `https://vahcare.co.uk/` (main website)
- `https://vahcare.co.uk/jobs.html` (jobs page)
- `https://vahcare.co.uk/admin-login.html` (admin login)

## 🎯 **Quick Upload Commands (if using FTP):**

```bash
# Upload all files at once
ftp your-domain.com
cd public_html
put -r VAH_Care_Upload/public_html/*

# Set permissions
chmod 644 *.html *.css *.js
chmod 644 backend/*.php
chmod 755 backend/ images/ backend/uploads/ backend/uploads/resumes/
chmod 666 backend/cms-jobs.json backend/cms-stats.json
```

## ✅ **Final Checklist:**

After upload, verify:
- [ ] Website loads without errors
- [ ] Contact form sends emails
- [ ] Job listings display correctly
- [ ] Job applications work
- [ ] Admin panel login works
- [ ] Job management functions
- [ ] File uploads work
- [ ] All images display correctly

**🎉 Your VAH Care website is now live!**
