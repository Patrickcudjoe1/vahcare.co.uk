<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}

$jobsFile = __DIR__ . '/cms-jobs.json';
$statsFile = __DIR__ . '/cms-stats.json';

function loadJobs() {
    global $jobsFile;
    if (file_exists($jobsFile)) {
        $data = json_decode(file_get_contents($jobsFile), true);
        return $data['data']['jobs'] ?? [];
    }
    return [];
}

function saveJobs($jobs) {
    global $jobsFile;
    $data = [
        'status' => 'success',
        'data' => [
            'jobs' => $jobs,
            'total_count' => count($jobs)
        ]
    ];
    file_put_contents($jobsFile, json_encode($data, JSON_PRETTY_PRINT));
}

function updateStats() {
    global $statsFile;
    $jobs = loadJobs();
    $activeJobs = 0;
    $categories = [];
    $locations = [];
    
    foreach ($jobs as $job) {
        if ($job['status'] === 'active') {
            $activeJobs++;
        }
        if (!in_array($job['category'], $categories)) {
            $categories[] = $job['category'];
        }
        if (!in_array($job['location'], $locations)) {
            $locations[] = $job['location'];
        }
    }
    
    $stats = [
        'status' => 'success',
        'data' => [
            'total_jobs' => count($jobs),
            'active_jobs' => $activeJobs,
            'categories' => count($categories),
            'locations' => count($locations)
        ]
    ];
    
    file_put_contents($statsFile, json_encode($stats, JSON_PRETTY_PRINT));
}

try {
    $method = $_SERVER['REQUEST_METHOD'];
    $action = $_GET['action'] ?? '';
    
    switch ($method) {
        case 'GET':
            if ($action === 'jobs') {
                $jobs = loadJobs();
                echo json_encode([
                    'status' => 'success',
                    'data' => [
                        'jobs' => $jobs,
                        'total_count' => count($jobs)
                    ]
                ]);
            } elseif ($action === 'stats') {
                $jobs = loadJobs();
                $activeJobs = 0;
                $categories = [];
                $locations = [];
                
                foreach ($jobs as $job) {
                    if ($job['status'] === 'active') {
                        $activeJobs++;
                    }
                    if (!in_array($job['category'], $categories)) {
                        $categories[] = $job['category'];
                    }
                    if (!in_array($job['location'], $locations)) {
                        $locations[] = $job['location'];
                    }
                }
                
                echo json_encode([
                    'status' => 'success',
                    'data' => [
                        'total_jobs' => count($jobs),
                        'active_jobs' => $activeJobs,
                        'categories' => count($categories),
                        'locations' => count($locations)
                    ]
                ]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
            }
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            
            if ($action === 'create_job') {
                $jobs = loadJobs();
                
                $newJob = [
                    'id' => time() . rand(100, 999), // Simple ID generation
                    'title' => $input['title'] ?? '',
                    'company' => 'VAH Care',
                    'location' => $input['location'] ?? '',
                    'category' => $input['category'] ?? '',
                    'description' => $input['description'] ?? '',
                    'requirements' => $input['requirements'] ?? '',
                    'salary' => $input['salary'] ?? '',
                    'job_type' => $input['job_type'] ?? 'Full-time',
                    'status' => $input['status'] ?? 'active',
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];
                
                $jobs[] = $newJob;
                saveJobs($jobs);
                updateStats();
                
                echo json_encode(['status' => 'success', 'message' => 'Job created successfully']);
                
            } elseif ($action === 'update_job') {
                $jobId = $_GET['id'] ?? '';
                $jobs = loadJobs();
                
                foreach ($jobs as &$job) {
                    if ($job['id'] == $jobId) {
                        $job['title'] = $input['title'] ?? $job['title'];
                        $job['location'] = $input['location'] ?? $job['location'];
                        $job['category'] = $input['category'] ?? $job['category'];
                        $job['description'] = $input['description'] ?? $job['description'];
                        $job['requirements'] = $input['requirements'] ?? $job['requirements'];
                        $job['salary'] = $input['salary'] ?? $job['salary'];
                        $job['job_type'] = $input['job_type'] ?? $job['job_type'];
                        $job['status'] = $input['status'] ?? $job['status'];
                        $job['updated_at'] = date('Y-m-d H:i:s');
                        break;
                    }
                }
                
                saveJobs($jobs);
                updateStats();
                
                echo json_encode(['status' => 'success', 'message' => 'Job updated successfully']);
                
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
            }
            break;
            
        case 'DELETE':
            if ($action === 'delete_job') {
                $jobId = $_GET['id'] ?? '';
                $jobs = loadJobs();
                $found = false;
                
                foreach ($jobs as $key => $job) {
                    if ($job['id'] == $jobId) {
                        unset($jobs[$key]);
                        $found = true;
                        break;
                    }
                }
                
                if ($found) {
                    $jobs = array_values($jobs); // Re-index array
                    saveJobs($jobs);
                    updateStats();
                    echo json_encode(['status' => 'success', 'message' => 'Job deleted successfully']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Job not found']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
