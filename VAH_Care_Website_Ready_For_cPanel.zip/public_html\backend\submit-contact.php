<?php
// Start output buffering to prevent any accidental output
ob_start();

// Disable HTML error output for API endpoints
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);

require_once 'config.php';

// Clean any output that might have been generated
ob_clean();

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['status' => 'error', 'message' => 'Method not allowed'], 405);
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Log the incoming request for debugging
logData(['method' => $_SERVER['REQUEST_METHOD'], 'input' => $input], 'DEBUG');

// Check if JSON decoding failed
if (json_last_error() !== JSON_ERROR_NONE) {
    logData('JSON decode error: ' . json_last_error_msg(), 'ERROR');
    sendJsonResponse(['status' => 'error', 'message' => 'Invalid JSON data'], 400);
}

// Validate required fields
$required = ['firstName', 'lastName', 'email', 'message'];
$missingFields = [];

foreach ($required as $field) {
    if (empty($data[$field]) || trim($data[$field]) === '') {
        $missingFields[] = $field;
    }
}

if (!empty($missingFields)) {
    logData('Missing required fields: ' . implode(', ', $missingFields), 'ERROR');
    sendJsonResponse(['status' => 'error', 'message' => 'Please fill in all required fields: ' . implode(', ', $missingFields)], 400);
}

// Sanitize input data
$data['firstName'] = sanitizeInput($data['firstName']);
$data['lastName'] = sanitizeInput($data['lastName']);
$data['email'] = sanitizeInput($data['email']);
$data['message'] = sanitizeInput($data['message']);
$data['phone'] = isset($data['phone']) ? sanitizeInput($data['phone']) : '';
$data['service'] = isset($data['service']) ? sanitizeInput($data['service']) : '';

// Validate email
if (!isValidEmail($data['email'])) {
    logData('Invalid email: ' . $data['email'], 'ERROR');
    sendJsonResponse(['status' => 'error', 'message' => 'Invalid email address'], 400);
}

try {
    // Prepare email
    $to = COMPANY_EMAIL;
    $subject = EMAIL_SUBJECT_PREFIX . "New Contact Form Submission";

    $message = "
<html>
<head>
    <title>New Contact Form Submission</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .content { padding: 20px; }
        .field { margin-bottom: 15px; }
        .label { font-weight: bold; color: #555; }
        .value { margin-left: 10px; }
        .cover-letter { margin-top: 10px; padding: 15px; background-color: #f8f9fa; border-radius: 5px; }
    </style>
</head>
<body>
    <div class='header'>
        <h2>New Contact Form Submission</h2>
        <p>Received: " . date('Y-m-d H:i:s') . "</p>
    </div>
    <div class='content'>
        <div class='field'>
            <span class='label'>Name:</span>
            <span class='value'>{$data['firstName']} {$data['lastName']}</span>
        </div>
        <div class='field'>
            <span class='label'>Email:</span>
            <span class='value'>{$data['email']}</span>
        </div>
        <div class='field'>
            <span class='label'>Phone:</span>
            <span class='value'>" . ($data['phone'] ?: 'Not provided') . "</span>
        </div>
        <div class='field'>
            <span class='label'>Service Interest:</span>
            <span class='value'>" . ($data['service'] ?: 'Not specified') . "</span>
        </div>
        <div class='field'>
            <span class='label'>Message:</span>
            <div class='value' style='margin-top: 10px; padding: 15px; background-color: #f8f9fa; border-radius: 5px;'>
                " . nl2br(htmlspecialchars($data['message'])) . "
            </div>
        </div>
    </div>
</body>
</html>
";

    // Email headers
    $headers = [
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=UTF-8',
        // Changed 'From' header to use COMPANY_EMAIL
        'From: VAH Care Website <' . COMPANY_EMAIL . '>',
        'Reply-To: ' . $data['email'],
        'X-Mailer: PHP/' . phpversion(),
        'X-Priority: 1'
    ];

    // Send email
    $mailSent = mail($to, $subject, $message, implode("\r\n", $headers));

    if (!$mailSent) {
        throw new Exception('Mail function failed - please check server mail configuration');
    }

    // Log success
    logData('Contact form email sent successfully to ' . $to, 'INFO');

    // Success response
    sendJsonResponse([
        'status' => 'success',
        'message' => 'Thank you for your message! We will get back to you soon.'
    ]);
} catch (Exception $e) {
    logData("Contact form error: " . $e->getMessage(), 'ERROR');
    sendJsonResponse([
        'status' => 'error',
        'message' => 'Failed to send message. Please try again later.',
        'debug' => $isDevelopment ? $e->getMessage() : null
    ], 500);
}
