console.log('Script.js loaded!')

// Base URL configuration
const baseUrl = (() => {
  const hostname = window.location.hostname;
  const isLocalhost = hostname === "localhost" || hostname === "127.0.0.1" || hostname.startsWith("192.168.");
  return isLocalhost 
    ? `${window.location.protocol}//${hostname}:${window.location.port}/backend/`
    : "https://vahcare.co.uk/backend/";
})();

console.log('Base URL set to:', baseUrl)

// DOM Content Loaded
document.addEventListener("DOMContentLoaded", () => {
  console.log('DOM Content Loaded event fired!')
  console.log('Current pathname:', window.location.pathname)
  
  initMobileMenu()
  initSmoothScrolling()
  initContactForm()
  initJobApplications()
  initScrollAnimations()
  initHeaderScroll()
  // Initialize job search if on jobs page
  if (window.location.pathname.includes("jobs.html")) {
    console.log('On jobs page, initializing job search and loading jobs...')
    initJobSearch()
    loadJobsFromCMS()
  } else {
    console.log('Not on jobs page')
  }
})

// Mobile Menu Toggle
function initMobileMenu() {
  const navToggle = document.querySelector(".nav-toggle")
  const navMenu = document.querySelector(".nav-menu")

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      navToggle.classList.toggle("active")
      navMenu.classList.toggle("active")
      document.body.style.overflow = navMenu.classList.contains("active") ? "hidden" : ""
    })

    const navLinks = navMenu.querySelectorAll(".nav-link")
    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.classList.remove("active")
        navMenu.classList.remove("active")
        document.body.style.overflow = ""
      })
    })

    document.addEventListener("click", (e) => {
      if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
        navToggle.classList.remove("active")
        navMenu.classList.remove("active")
        document.body.style.overflow = ""
      }
    })
  }
}

// Smooth Scrolling
function initSmoothScrolling() {
  const links = document.querySelectorAll('a[href^="#"]')
  links.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()
      const targetId = this.getAttribute("href")
      const targetSection = document.querySelector(targetId)
      if (targetSection) {
        const headerHeight = document.querySelector(".header").offsetHeight
        const targetPosition = targetSection.offsetTop - headerHeight - 20
        window.scrollTo({
          top: targetPosition,
          behavior: "smooth",
        })
      }
    })
  })
}

// Contact Form Handling
function initContactForm() {
  const contactForm = document.querySelector(".contact-form")
  if (contactForm) {
    contactForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const submitBtn = contactForm.querySelector('button[type="submit"]')
      const originalText = submitBtn.textContent
      submitBtn.textContent = "Sending..."
      submitBtn.disabled = true

      const formData = new FormData(contactForm)
      const data = {
        firstName: formData.get("firstName"),
        lastName: formData.get("lastName"),
        email: formData.get("email"),
        phone: formData.get("phone"),
        service: formData.get("service"),
        message: formData.get("message"),
      }

      if (validateContactForm(data)) {
        try {
          const response = await sendContactEmail(data) // Pass the plain data object
          if (response.status === "success") {
            showMessage("Thank you for your message! We'll get back to you.", "success")
            contactForm.reset()
          } else {
            showMessage(response.message || "Failed to send message. Please try again.", "error")
          }
        } catch (error) {
          console.error("Contact form submission error:", error)
          showMessage("Failed to send message. Please try again.", "error")
        }
      } else {
        showMessage("Please fill in all required fields correctly.", "error")
      }

      submitBtn.textContent = originalText
      submitBtn.disabled = false
    })
  }
}

// Job Applications Handling
function initJobApplications() {
  const applyButtons = document.querySelectorAll(".job-card .btn-primary")
  applyButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const jobCard = this.closest(".job-card")
      const jobTitle = jobCard.querySelector(".job-title").textContent
      const jobCompany = jobCard.querySelector(".job-company").textContent // Not used in modal, but good to keep
      openJobApplicationModal(jobTitle, jobCompany)
    })
  })
}

// Modal Functions
function openJobApplicationModal(jobTitle, company) {
  let modal = document.getElementById("jobApplicationModal")
  if (!modal) {
    modal = createJobApplicationModal()
    document.body.appendChild(modal)
  }

  const modalTitle = modal.querySelector(".modal-title")
  const jobTitleInput = modal.querySelector("#jobTitle")
  modalTitle.textContent = `Apply for ${jobTitle}`
  jobTitleInput.value = jobTitle

  // Re-attach event listeners every time modal is opened
  const closeBtn = modal.querySelector(".modal-close")
  const cancelBtn = modal.querySelector(".modal-cancel")
  
  // Remove existing listeners to prevent duplicates
  closeBtn.replaceWith(closeBtn.cloneNode(true))
  cancelBtn.replaceWith(cancelBtn.cloneNode(true))
  
  // Get fresh references after cloning
  const newCloseBtn = modal.querySelector(".modal-close")
  const newCancelBtn = modal.querySelector(".modal-cancel")
  
  newCloseBtn.addEventListener("click", () => {
    console.log('Close button clicked')
    closeJobApplicationModal()
  })
  
  newCancelBtn.addEventListener("click", () => {
    console.log('Cancel button clicked')
    closeJobApplicationModal()
  })

  modal.style.display = "flex"
  document.body.style.overflow = "hidden"

  const form = modal.querySelector(".job-application-form")
  form.onsubmit = async (e) => {
    e.preventDefault()
    const submitBtn = form.querySelector('button[type="submit"]')
    const originalText = submitBtn.textContent
    submitBtn.textContent = "Submitting..."
    submitBtn.disabled = true

    const formData = new FormData(form)
    // jobTitle is already set in the hidden input, no need to append again if it's there
    // formData.append("jobTitle", jobTitle);

    // Extract data for validation and email sending
    const data = {
      jobTitle: formData.get("jobTitle"),
      firstName: formData.get("firstName"),
      lastName: formData.get("lastName"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      experience: formData.get("experience"),
      availability: formData.get("availability"),
      coverLetter: formData.get("coverLetter"),
      resume: formData.get("resume"), // This will be the File object
    }

    if (validateJobApplication(data)) {
      try {
        const response = await sendJobApplicationEmail(formData) // Send formData directly for file upload
        if (response.status === "success") {
          showMessage("Application submitted successfully!", "success")
          setTimeout(() => closeJobApplicationModal(), 2000)
        } else {
          showMessage(response.message || "Failed to submit application. Please try again.", "error")
        }
      } catch (error) {
        console.error("Job application submission error:", error)
        showMessage("Failed to submit application. Please try again.", "error")
      }
    } else {
      showMessage("Please fill in all required fields correctly.", "error")
    }

    submitBtn.textContent = originalText
    submitBtn.disabled = false
  }
}

function createJobApplicationModal() {
  const modal = document.createElement("div")
  modal.id = "jobApplicationModal"
  modal.className = "modal"
  modal.innerHTML = `
  <div class="modal-content">
    <div class="modal-header">
      <h2 class="modal-title">Apply for Position</h2>
      <span class="modal-close">&times;</span>
    </div>
    <div class="modal-body">
      <form class="job-application-form">
        <input type="hidden" id="jobTitle" name="jobTitle">
        <div class="form-row">
          <div class="form-group">
            <label for="applicantFirstName">First Name *</label>
            <input type="text" id="applicantFirstName" name="firstName" autocomplete="given-name" required>
          </div>
          <div class="form-group">
            <label for="applicantLastName">Last Name *</label>
            <input type="text" id="applicantLastName" name="lastName" autocomplete="family-name" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="applicantEmail">Email *</label>
            <input type="email" id="applicantEmail" name="email" autocomplete="email" required>
          </div>
          <div class="form-group">
            <label for="applicantPhone">Phone *</label>
            <input type="tel" id="applicantPhone" name="phone" autocomplete="tel" required>
          </div>
        </div>
        <div class="form-group">
          <label for="experience">Experience *</label>
          <select id="experience" name="experience" required>
            <option value="">Select experience</option>
            <option value="0-1">0-1 years</option>
            <option value="2-5">2-5 years</option>
            <option value="6-10">6-10 years</option>
            <option value="10+">10+ years</option>
          </select>
        </div>
        <div class="form-group">
          <label for="availability">Availability *</label>
          <select id="availability" name="availability" required>
            <option value="">Select availability</option>
            <option value="immediate">Immediate</option>
            <option value="2-weeks">2 weeks notice</option>
            <option value="1-month">1 month notice</option>
            <option value="flexible">Flexible</option>
          </select>
        </div>
        <div class="form-group">
          <label for="coverLetter">Cover Letter *</label>
          <textarea id="coverLetter" name="coverLetter" required></textarea>
        </div>
        <div class="form-group">
          <label for="resume">Resume</label>
          <input type="file" id="resume" name="resume" accept=".pdf,.doc,.docx">
        </div>
        <div class="form-actions">
          <button type="button" class="btn btn-outline modal-cancel">Cancel</button>
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  </div>
`

  const style = document.createElement("style")
  style.textContent = `
  .modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    align-items: center;
    justify-content: center;
  }
  .modal-content {
    background: white;
    border-radius: 12px;
    width: 90%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
  }
  .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 2rem 2rem 1rem;
    border-bottom: 1px solid #e5e7eb;
  }
  .modal-title {
    font-size: 1.5rem;
    font-weight: 700;
    margin: 0;
  }
  .modal-close {
    font-size: 2rem;
    cursor: pointer;
  }
  .modal-body {
    padding: 2rem;
  }
  .form-actions {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    margin-top: 2rem;
  }
`
  document.head.appendChild(style)

  // Background click to close modal
  modal.addEventListener("click", (e) => {
    if (e.target === modal) {
      console.log('Modal background clicked')
      closeJobApplicationModal()
    }
  })

  return modal
}

function closeJobApplicationModal() {
  const modal = document.getElementById("jobApplicationModal")
  if (modal) {
    modal.style.display = "none"
    document.body.style.overflow = ""
    const form = modal.querySelector(".job-application-form")
    form.reset()
  }
}

// Email Sending Functions
async function sendContactEmail(data) {
  // Changed parameter to 'data'
  try {
    // Use http for localhost, and the current page's protocol for the live site
    const baseUrl =
      window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1" || window.location.hostname === "192.168.0.176"
        ? "http://192.168.0.176:8000/backend/" // Updated for PHP development server
        : "https://vahcare.co.uk/backend/"

    const response = await fetch(`${baseUrl}submit-contact.php`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json", // Set Content-Type for JSON
      },
      body: JSON.stringify(data), // Stringify the data object
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error sending contact email:", error)
    return {
      status: "error",
      message: "Failed to connect to server.",
    }
  }
}

async function sendJobApplicationEmail(formData) {
  // Parameter is already FormData
  try {
    // Use http for localhost, and the current page's protocol for the live site
    const baseUrl =
      window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1" || window.location.hostname === "192.168.0.176"
        ? "http://192.168.0.176:8000/backend/" // Updated for PHP development server
        : "https://vahcare.co.uk/backend/"

    const response = await fetch(`${baseUrl}submit-job-application.php`, {
      method: "POST",
      body: formData, // FormData is sent directly for file uploads
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error sending job application:", error)
    return {
      status: "error",
      message: "Failed to connect to server.",
    }
  }
}

// Form Validation
function validateContactForm(data) {
  const required = ["firstName", "lastName", "email", "message"]
  for (const field of required) {
    if (!data[field] || data[field].trim() === "") return false
  }
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)
}

function validateJobApplication(data) {
  const required = ["firstName", "lastName", "email", "phone", "experience", "availability", "coverLetter"]
  for (const field of required) {
    if (!data[field] || data[field].toString().trim() === "") return false
  }
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)
}

// Message Display
function showMessage(message, type) {
  const existingMessages = document.querySelectorAll(".form-message")
  existingMessages.forEach((msg) => msg.remove())

  const messageEl = document.createElement("div")
  messageEl.className = `form-message ${type}`
  messageEl.textContent = message
  messageEl.style.cssText = `
  position: fixed;
  top: 20px;
  right: 20px;
  padding: 1rem 1.5rem;
  border-radius: 8px;
  color: white;
  font-weight: 500;
  z-index: 3000;
  max-width: 400px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  animation: slideInRight 0.3s ease-out;
  background-color: ${type === "success" ? "#10b981" : "#ef4444"};
`

  if (!document.getElementById("messageStyles")) {
    const style = document.createElement("style")
    style.id = "messageStyles"
    style.textContent = `
    @keyframes slideInRight {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `
    document.head.appendChild(style)
  }

  document.body.appendChild(messageEl)
  setTimeout(() => {
    messageEl.style.animation = "slideInRight 0.3s ease-out reverse"
    setTimeout(() => messageEl.remove(), 300)
  }, 5000)
}

// Scroll Animations
function initScrollAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("animate-in")
        }
      })
    },
    {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px",
    },
  )

  document
    .querySelectorAll(".promise-card, .service-card, .recruitment-card, .benefit-card, .job-card")
    .forEach((el) => {
      observer.observe(el)
    })

  const style = document.createElement("style")
  style.textContent = `
  .promise-card,
  .service-card,
  .recruitment-card,
  .benefit-card,
  .job-card {
    opacity: 0;
    transform: translateY(30px);
    transition: opacity 0.6s ease, transform 0.6s ease;
  }
  .promise-card.animate-in,
  .service-card.animate-in,
  .recruitment-card.animate-in,
  .benefit-card.animate-in,
  .job-card.animate-in {
    opacity: 1;
    transform: translateY(0);
  }
`
  document.head.appendChild(style)
}

// Header Scroll Effect
function initHeaderScroll() {
  const header = document.querySelector(".header")
  let lastScrollTop = 0

  window.addEventListener("scroll", () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop
    if (scrollTop > 50) {
      header.classList.add("scrolled")
    } else {
      header.classList.remove("scrolled")
    }

    if (scrollTop > lastScrollTop && scrollTop > 200) {
      header.style.transform = "translateY(-100%)"
    } else {
      header.style.transform = "translateY(0)"
    }
    lastScrollTop = scrollTop <= 0 ? 0 : scrollTop
  })

  const style = document.createElement("style")
  style.textContent = `
  .header {
    transition: transform 0.3s ease, background-color 0.3s ease;
  }
  .header.scrolled {
    background-color: rgba(255,255,255,0.98);
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  }
`
  document.head.appendChild(style)
}

// Job Search Functionality
function initJobSearch() {
  const searchInput = document.querySelector(".search-input-group input")
  const searchBtn = document.querySelector(".search-btn")
  const searchTags = document.querySelectorAll(".search-tag")

  if (searchBtn) searchBtn.addEventListener("click", performSearch)
  if (searchInput)
    searchInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") performSearch()
    })

  searchTags.forEach((tag) => {
    tag.addEventListener("click", function () {
      if (searchInput) {
        searchInput.value = this.textContent
        performSearch()
      }
    })
  })
}

function performSearch() {
  const searchInput = document.querySelector(".search-input-group input")
  const searchTerm = searchInput ? searchInput.value.toLowerCase() : ""
  const jobCards = document.querySelectorAll(".job-card")

  jobCards.forEach((card) => {
    const title = card.querySelector(".job-title").textContent.toLowerCase()
    const description = card.querySelector(".job-description").textContent.toLowerCase()
    const category = card.querySelector(".job-meta-item:last-child span").textContent.toLowerCase()

    if (title.includes(searchTerm) || description.includes(searchTerm) || category.includes(searchTerm)) {
      card.style.display = "block"
    } else {
      card.style.display = "none"
    }
  })
}

// Load jobs from Custom CMS
async function loadJobsFromCMS() {
  try {
    console.log('Loading jobs from Custom CMS...')
    console.log('Base URL:', baseUrl)
    
    const response = await fetch(`${baseUrl}public-jobs.php`)
    console.log('Response status:', response.status)
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    
    const data = await response.json()
    console.log('Jobs data from Custom CMS:', data)
    
    if (data.status === 'success') {
      console.log('Jobs loaded successfully from Custom CMS, count:', data.data.jobs.length)
      renderJobsFromCMS(data.data.jobs)
    } else {
      console.error('Failed to load jobs from Custom CMS:', data.message)
      showJobsError('Failed to load jobs. Please try again later.')
    }
  } catch (error) {
    console.error('Error loading jobs from Custom CMS:', error)
    showJobsError('Failed to load jobs. Please try again later.')
  }
}



function renderJobsFromCMS(jobs) {
  console.log('Rendering jobs:', jobs)
  const jobsGrid = document.getElementById('jobsGrid')
  
  if (!jobsGrid) {
    console.error('jobsGrid element not found!')
    return
  }
  
  console.log('Found jobsGrid element')
  console.log('jobsGrid current innerHTML:', jobsGrid.innerHTML)
  console.log('jobsGrid style:', jobsGrid.style.cssText)
  console.log('jobsGrid offsetParent:', jobsGrid.offsetParent)
  console.log('jobsGrid getBoundingClientRect:', jobsGrid.getBoundingClientRect())
  console.log('jobsGrid parent:', jobsGrid.parentElement)
  console.log('jobsGrid parent tagName:', jobsGrid.parentElement.tagName)
  console.log('jobsGrid parent className:', jobsGrid.parentElement.className)
  
  if (jobs.length === 0) {
    console.log('No jobs to display')
    jobsGrid.innerHTML = '<div class="loading">No jobs available at the moment. Please check back later!</div>'
    return
  }
  
  console.log('Rendering', jobs.length, 'jobs')
  
  // Filter out inactive jobs
  const activeJobs = jobs.filter(job => job.status === 'active')
  console.log('Active jobs:', activeJobs.length)
  
  if (activeJobs.length === 0) {
    console.log('No active jobs to display')
    jobsGrid.innerHTML = '<div class="loading">No active jobs available at the moment. Please check back later!</div>'
    return
  }
  
  const jobsHTML = activeJobs.map(job => `
    <div style="background: #ffffff !important; border: 1px solid #e5e7eb !important; border-radius: 12px !important; padding: 1.5rem !important; margin-bottom: 1rem !important; box-shadow: 0 2px 4px rgba(0,0,0,0.1) !important; transition: all 0.3s ease !important; display: block !important;">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
        <div>
          <h3 style="font-size: 1.25rem; font-weight: 600; color: #1f2937; margin-bottom: 0.25rem;">${job.title}</h3>
          <p style="color: #2563eb; font-weight: 500; font-size: 0.875rem;">${job.company}</p>
        </div>
        <span style="background: #eff6ff; color: #2563eb; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.75rem; font-weight: 500;">${job.job_type}</span>
      </div>
      <div style="display: flex; flex-wrap: wrap; gap: 1rem; margin-bottom: 1rem; font-size: 0.875rem; color: #6b7280;">
        <div style="display: flex; align-items: center; gap: 0.25rem;">
          <i class="fas fa-map-marker-alt" style="color: #9ca3af;"></i>
          <span>${job.location}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 0.25rem;">
          <i class="fas fa-clock" style="color: #9ca3af;"></i>
          <span>${job.job_type}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 0.25rem;">
          <i class="fas fa-briefcase" style="color: #9ca3af;"></i>
          <span>${job.category}</span>
        </div>
      </div>
      <p style="color: #6b7280; line-height: 1.6; margin-bottom: 1rem;">${job.description}</p>
      <div style="margin-bottom: 1.5rem;">
        <h4 style="font-size: 0.875rem; font-weight: 600; color: #374151; margin-bottom: 0.5rem;">Key Requirements:</h4>
        <div style="color: #6b7280; font-size: 0.875rem;">${job.requirements}</div>
      </div>

      <div style="margin-top: 1.5rem;">
        <button onclick="openJobApplicationModal('${job.title}', '${job.company}')" style="background: #2563eb; color: white; padding: 0.75rem 1.5rem; border: none; border-radius: 8px; font-weight: 500; cursor: pointer; transition: background-color 0.3s ease;">Apply Now</button>
      </div>
    </div>
  `).join('')
  

  
  // Now try to set the innerHTML
  try {
    console.log('About to set innerHTML with:', jobsHTML.substring(0, 200) + '...')
    
    // Force jobsGrid to be visible and properly styled
    jobsGrid.style.display = 'flex'
    jobsGrid.style.flexDirection = 'column'
    jobsGrid.style.gap = '1.5rem'
    jobsGrid.style.visibility = 'visible'
    jobsGrid.style.opacity = '1'
    
    jobsGrid.innerHTML = jobsHTML
    console.log('Jobs rendered successfully')
    console.log('jobsGrid innerHTML after setting:', jobsGrid.innerHTML.substring(0, 200) + '...')
    

    
    // Check if job cards are actually rendered
    const renderedCards = jobsGrid.querySelectorAll('.job-card')
    console.log('Number of job cards rendered:', renderedCards.length)
    
    // Debug: Check if cards are visible
    if (renderedCards.length > 0) {
      console.log('First card computed style:', window.getComputedStyle(renderedCards[0]))
      console.log('First card offsetHeight:', renderedCards[0].offsetHeight)
      console.log('First card clientHeight:', renderedCards[0].clientHeight)
      console.log('jobsGrid offsetHeight:', jobsGrid.offsetHeight)
      console.log('jobsGrid clientHeight:', jobsGrid.clientHeight)
    }
    

    
  } catch (error) {
    console.error('Error setting innerHTML:', error)
  }


}

function showJobsError(message) {
  const jobsGrid = document.getElementById('jobsGrid')
  if (jobsGrid) {
    jobsGrid.innerHTML = `<div class="error-message">${message}</div>`
  }
}
