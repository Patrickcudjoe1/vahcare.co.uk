// VAH Care Custom CMS Admin JavaScript
// Replaces Contentful with custom JSON-based CMS

class CustomCMSAdmin {
    constructor() {
        this.apiUrl = '../backend/cms-api.php';
        this.currentJobId = null;
        this.init();
    }
    
    init() {
        this.loadDashboard();
        this.setupEventListeners();
    }
    
    setupEventListeners() {
        document.getElementById('jobForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveJob();
        });
    }
    
    async loadDashboard() {
        try {
            await Promise.all([
                this.loadStats(),
                this.loadJobs()
            ]);
        } catch (error) {
            console.error('Error loading dashboard:', error);
            this.showError('Failed to load dashboard data');
        }
    }
    
    async loadStats() {
        try {
            const response = await fetch(`${this.apiUrl}?action=stats`);
            const data = await response.json();
            
            if (data.status === 'success') {
                this.displayStats(data.data);
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }
    
    displayStats(stats) {
        const statsContainer = document.getElementById('stats');
        statsContainer.innerHTML = `
            <div class="stat-card">
                <div class="stat-number">${stats.total_jobs}</div>
                <div class="stat-label">Total Jobs</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${stats.active_jobs}</div>
                <div class="stat-label">Active Jobs</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${stats.categories}</div>
                <div class="stat-label">Categories</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${stats.locations}</div>
                <div class="stat-label">Locations</div>
            </div>
        `;
    }
    
    async loadJobs() {
        try {
            const response = await fetch(`${this.apiUrl}?action=jobs`);
            const data = await response.json();
            
            if (data.status === 'success') {
                this.displayJobs(data.data.jobs);
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Error loading jobs:', error);
            this.showError('Failed to load jobs');
        }
    }
    
    displayJobs(jobs) {
        const jobsContainer = document.getElementById('jobs-list');
        
        if (jobs.length === 0) {
            jobsContainer.innerHTML = '<div class="loading">No jobs found. Add your first job!</div>';
            return;
        }
        
        jobsContainer.innerHTML = jobs.map(job => `
            <div class="job-card">
                <div class="job-header">
                    <h3 class="job-title">${job.title}</h3>
                    <span class="job-status status-${job.status}">${job.status}</span>
                </div>
                <div class="job-meta">
                    <span><i class="fas fa-map-marker-alt"></i> ${job.location}</span>
                    <span><i class="fas fa-tag"></i> ${job.category}</span>
                    <span><i class="fas fa-clock"></i> ${job.job_type}</span>
                    <span><i class="fas fa-calendar"></i> ${new Date(job.updated_at).toLocaleDateString()}</span>
                </div>
                <div class="job-actions">
                    <button class="action-btn edit-btn" onclick="cmsAdmin.editJob(${job.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="action-btn delete-btn" onclick="cmsAdmin.deleteJob(${job.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    openJobModal(jobId = null) {
        this.currentJobId = jobId;
        const modal = document.getElementById('jobModal');
        const modalTitle = document.getElementById('modalTitle');
        
        if (jobId) {
            modalTitle.textContent = 'Edit Job';
            this.loadJobData(jobId);
        } else {
            modalTitle.textContent = 'Add New Job';
            this.clearJobForm();
        }
        
        modal.style.display = 'block';
    }
    
    closeJobModal() {
        document.getElementById('jobModal').style.display = 'none';
        this.currentJobId = null;
        this.clearJobForm();
    }
    
    clearJobForm() {
        document.getElementById('jobForm').reset();
    }
    
    async loadJobData(jobId) {
        try {
            const jobs = await this.getJobs();
            const job = jobs.find(j => j.id == jobId);
            
            if (job) {
                this.populateJobForm(job);
            } else {
                throw new Error('Job not found');
            }
        } catch (error) {
            console.error('Error loading job data:', error);
            this.showError('Failed to load job data');
        }
    }
    
    async getJobs() {
        const response = await fetch(`${this.apiUrl}?action=jobs`);
        const data = await response.json();
        
        if (data.status === 'success') {
            return data.data.jobs;
        } else {
            throw new Error(data.message);
        }
    }
    
    populateJobForm(job) {
        document.getElementById('jobTitle').value = job.title;
        document.getElementById('jobLocation').value = job.location;
        document.getElementById('jobCategory').value = job.category;
        document.getElementById('jobType').value = job.job_type;
        document.getElementById('jobSalary').value = job.salary;
        document.getElementById('jobDescription').value = job.description;
        document.getElementById('jobRequirements').value = job.requirements;
        document.getElementById('jobStatus').value = job.status;
    }
    
    async saveJob() {
        const formData = {
            title: document.getElementById('jobTitle').value,
            location: document.getElementById('jobLocation').value,
            category: document.getElementById('jobCategory').value,
            job_type: document.getElementById('jobType').value,
            salary: document.getElementById('jobSalary').value,
            description: document.getElementById('jobDescription').value,
            requirements: document.getElementById('jobRequirements').value,
            status: document.getElementById('jobStatus').value
        };
        
        try {
            const url = this.currentJobId 
                ? `${this.apiUrl}?action=update_job&id=${this.currentJobId}`
                : `${this.apiUrl}?action=create_job`;
            
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.showSuccess(this.currentJobId ? 'Job updated successfully!' : 'Job created successfully!');
                this.closeJobModal();
                this.loadDashboard();
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Error saving job:', error);
            this.showError('Failed to save job: ' + error.message);
        }
    }
    
    async deleteJob(jobId) {
        if (!confirm('Are you sure you want to delete this job? This action cannot be undone.')) {
            return;
        }
        
        try {
            const response = await fetch(`${this.apiUrl}?action=delete_job&id=${jobId}`, {
                method: 'DELETE'
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.showSuccess('Job deleted successfully!');
                this.loadDashboard();
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            console.error('Error deleting job:', error);
            this.showError('Failed to delete job: ' + error.message);
        }
    }
    
    editJob(jobId) {
        this.openJobModal(jobId);
    }
    
    showSuccess(message) {
        this.showMessage(message, 'success');
    }
    
    showError(message) {
        this.showMessage(message, 'error');
    }
    
    showMessage(message, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = type;
        messageDiv.textContent = message;
        
        const container = document.querySelector('.cms-container');
        container.insertBefore(messageDiv, container.firstChild);
        
        setTimeout(() => {
            messageDiv.remove();
        }, 5000);
    }
}

// Global functions for HTML onclick handlers
function openJobModal() {
    cmsAdmin.openJobModal();
}

function closeJobModal() {
    cmsAdmin.closeJobModal();
}

function refreshData() {
    if (cmsAdmin) {
        // Show loading state
        const statsContainer = document.getElementById('stats');
        const jobsContainer = document.getElementById('jobs-list');
        
        if (statsContainer) {
            statsContainer.innerHTML = '<div class="loading">Refreshing statistics...</div>';
        }
        if (jobsContainer) {
            jobsContainer.innerHTML = '<div class="loading">Refreshing jobs...</div>';
        }
        
        // Reload dashboard
        cmsAdmin.loadDashboard();
    } else {
        console.error('CMS Admin not initialized');
    }
}

async function logout() {
    try {
        const response = await fetch('../backend/admin-logout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const data = await response.json();
        
        if (data.status === 'success') {
            // Redirect to login page after successful logout
            window.location.href = 'admin-login.html';
        } else {
            console.error('Logout failed:', data.message);
            // Still redirect to login page even if logout fails
            window.location.href = 'admin-login.html';
        }
    } catch (error) {
        console.error('Logout error:', error);
        // Redirect to login page even if there's an error
        window.location.href = 'admin-login.html';
    }
}

// Initialize the CMS Admin when page loads
let cmsAdmin;
document.addEventListener('DOMContentLoaded', () => {
    cmsAdmin = new CustomCMSAdmin();
});

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('jobModal');
    if (event.target === modal) {
        closeJobModal();
    }
}
