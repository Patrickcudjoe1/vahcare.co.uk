<?php
// Environment detection - handle CLI and web requests
$isLocalhost = false;
if (php_sapi_name() === 'cli') {
    $isLocalhost = true;
} else {
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $isLocalhost = in_array($host, ['localhost', '127.0.0.1', 'localhost:8080', 'localhost:8000', '192.168.0.176:8000']);
}
$isDevelopment = $isLocalhost || (isset($_SERVER['SERVER_NAME']) && strpos($_SERVER['SERVER_NAME'], 'localhost') !== false);

// Email configuration
define('COMPANY_EMAIL', 'info@vahcare.co.uk');
define('JOBS_EMAIL', 'jobs@vahcare.co.uk');
define('EMAIL_SUBJECT_PREFIX', 'VAH Care: ');

// Database configuration - Using SQLite for simplicity
define('DB_PATH', __DIR__ . '/database/vahcare.db');
define('DB_DSN', 'sqlite:' . DB_PATH);

// Create database directory if it doesn't exist
if (!is_dir(__DIR__ . '/database')) {
    mkdir(__DIR__ . '/database', 0755, true);
}

// Error reporting (enable in development, disable in production)
if ($isDevelopment) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
}

// CORS configuration
function setCorsHeaders()
{
    global $isDevelopment;

    header("Content-Type: application/json");

    if ($isDevelopment) {
        // Allow localhost and local network for development - be more permissive for local testing
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Credentials: true");
    } else {
        // Restrict to your domain in production
        header("Access-Control-Allow-Origin: https://vahcare.co.uk");
        header("Access-Control-Allow-Credentials: true");
    }

    header("Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
}

/**
 * Logs data to error log with timestamp
 * @param mixed $data The data to log
 * @param string $type Log type (INFO, ERROR, DEBUG)
 */
function logData($data, $type = 'INFO')
{
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] VAH Care $type: " . print_r($data, true);
    // In a production environment, consider logging to a specific file
    // For cPanel, this usually goes to the server's error log by default.
    error_log($logMessage);
}

/**
 * Send JSON response and exit
 * @param array $data Response data
 * @param int $httpCode HTTP status code
 */
function sendJsonResponse($data, $httpCode = 200)
{
    http_response_code($httpCode);
    echo json_encode($data);
    exit;
}

/**
 * Validate email address
 * @param string $email Email to validate
 * @return bool
 */
function isValidEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Sanitize input data
 * @param string $data Input data
 * @return string Sanitized data
 */
function sanitizeInput($data)
{
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// Set CORS headers only for web requests
if (php_sapi_name() !== 'cli') {
    setCorsHeaders();
}
