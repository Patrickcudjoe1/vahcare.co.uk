<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$jobsFile = __DIR__ . '/cms-jobs.json';

function loadJobs() {
    global $jobsFile;
    try {
        if (!file_exists($jobsFile)) {
            error_log("Jobs file not found: $jobsFile");
            return [];
        }
        
        $content = file_get_contents($jobsFile);
        if ($content === false) {
            error_log("Failed to read jobs file: $jobsFile");
            return [];
        }
        
        $data = json_decode($content, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("JSON decode error in jobs file: " . json_last_error_msg());
            return [];
        }
        
        return $data['data']['jobs'] ?? [];
    } catch (Exception $e) {
        error_log("Error loading jobs: " . $e->getMessage());
        return [];
    }
}

try {
    $method = $_SERVER['REQUEST_METHOD'];
    
    if ($method === 'GET') {
        $jobs = loadJobs();
        
        // Only return active jobs for public access
        $activeJobs = array_filter($jobs, function($job) {
            return $job['status'] === 'active';
        });
        
        echo json_encode([
            'status' => 'success',
            'data' => [
                'jobs' => array_values($activeJobs),
                'total_count' => count($activeJobs)
            ]
        ]);
    } else {
        http_response_code(405);
        echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
