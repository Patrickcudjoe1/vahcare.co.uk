# 📁 cPanel Upload File Structure

## 🎯 **Upload Instructions:**

1. **Login to cPanel**
2. **Open File Manager**
3. **Navigate to `public_html/`**
4. **Upload files according to this structure:**

## 📂 **File Structure for cPanel:**

```
public_html/
├── 📄 index.html                    (Main website homepage)
├── 📄 jobs.html                     (Job listings page)
├── 📄 admin-login.html              (Admin login page)
├── 📄 admin-cms.html                (Admin CMS panel)
├── 📄 demo.html                     (Demo page for clients)
├── 📄 style.css                     (Main stylesheet)
├── 📄 script.js                     (Main JavaScript)
├── 📄 admin-cms.js                  (Admin CMS JavaScript)
│
├── 📁 images/                       (Images folder)
│   ├── 🖼️ logo.png                  (Company logo)
│   └── 🖼️ hero-banner.png           (Hero banner image)
│
└── 📁 backend/                      (Backend PHP files)
    ├── 📄 config.php                (Configuration file)
    ├── 📄 admin-login.php           (Admin login handler)
    ├── 📄 admin-logout.php          (Admin logout handler)
    ├── 📄 check-admin-session.php   (Session checker)
    ├── 📄 cms-api.php               (CMS API for admin)
    ├── 📄 public-jobs.php           (Public jobs API)
    ├── 📄 submit-contact.php        (Contact form handler)
    ├── 📄 submit-job-application.php (Job application handler)
    ├── 📄 cms-jobs.json             (Jobs data file)
    ├── 📄 cms-stats.json            (Statistics data file)
    │
    └── 📁 uploads/                  (File uploads folder)
        └── 📁 resumes/              (Resume uploads folder)
```

## 🔧 **Post-Upload Setup:**

### **1. Set File Permissions:**
```bash
# HTML, CSS, JS files
chmod 644 *.html *.css *.js

# PHP files
chmod 644 backend/*.php

# Directories
chmod 755 backend/
chmod 755 images/
chmod 755 backend/uploads/
chmod 755 backend/uploads/resumes/

# JSON data files (writable)
chmod 666 backend/cms-jobs.json
chmod 666 backend/cms-stats.json
```

### **2. Test All Features:**
- ✅ Main website: `https://vahcare.co.uk/`
- ✅ Jobs page: `https://vahcare.co.uk/jobs.html`
- ✅ Contact forms
- ✅ Job applications
- ✅ Admin panel: `https://vahcare.co.uk/admin-login.html`

## 📋 **Upload Checklist:**

### **Frontend Files (public_html/)**
- [ ] `index.html`
- [ ] `jobs.html`
- [ ] `admin-login.html`
- [ ] `admin-cms.html`
- [ ] `demo.html`
- [ ] `style.css`
- [ ] `script.js`
- [ ] `admin-cms.js`
- [ ] `images/` folder (with logo.png and hero-banner.png)

### **Backend Files (public_html/backend/)**
- [ ] `config.php`
- [ ] `admin-login.php`
- [ ] `admin-logout.php`
- [ ] `check-admin-session.php`
- [ ] `cms-api.php`
- [ ] `public-jobs.php`
- [ ] `submit-contact.php`
- [ ] `submit-job-application.php`
- [ ] `cms-jobs.json`
- [ ] `cms-stats.json`
- [ ] `uploads/resumes/` folder

## 🎯 **Live URLs After Upload:**

- **🌐 Main Website:** `https://vahcare.co.uk/`
- **💼 Jobs Page:** `https://vahcare.co.uk/jobs.html`
- **🔐 Admin Login:** `https://vahcare.co.uk/admin-login.html`
- **📋 Demo Page:** `https://vahcare.co.uk/demo.html`

## 🔑 **Admin Access:**
- **Username:** `admin`
- **Password:** `vahcare2024`

## 📧 **Email Addresses:**
- **Contact Forms:** `info@vahcare.co.uk`
- **Job Applications:** `jobs@vahcare.co.uk`

## ✅ **Final Verification:**

After upload, test:
1. **Website loads correctly**
2. **Contact form sends emails**
3. **Job listings display**
4. **Job applications work**
5. **Admin panel login works**
6. **Job management functions**
7. **File uploads work**

**🎉 Your VAH Care website will be live and fully functional!**
