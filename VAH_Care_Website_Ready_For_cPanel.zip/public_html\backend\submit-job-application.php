<?php
// Start output buffering to prevent any accidental output
ob_start();

// Disable HTML error output for API endpoints
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);

require_once 'config.php';

// Clean any output that might have been generated
ob_clean();

// Handle preflight requests (browsers send OPTIONS before POST)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['status' => 'error', 'message' => 'Method not allowed'], 405);
}

// Get form data from $_POST (for text fields) and $_FILES (for file uploads)
$data = $_POST;

// Log the incoming request for debugging
logData([
    'method' => $_SERVER['REQUEST_METHOD'],
    'post_data' => array_keys($data),
    'files' => array_keys($_FILES)
], 'DEBUG');

// Validate required fields
$required = ['firstName', 'lastName', 'email', 'phone', 'experience', 'availability', 'coverLetter', 'jobTitle'];
$missingFields = [];

foreach ($required as $field) {
    if (empty($data[$field]) || trim($data[$field]) === '') {
        $missingFields[] = $field;
    }
}

if (!empty($missingFields)) {
    logData('Missing required fields: ' . implode(', ', $missingFields), 'ERROR');
    sendJsonResponse(['status' => 'error', 'message' => 'Please fill in all required fields: ' . implode(', ', $missingFields)], 400);
}

// Sanitize input data
foreach ($data as $key => $value) {
    $data[$key] = sanitizeInput($value);
}

// Validate email
if (!isValidEmail($data['email'])) {
    logData('Invalid email: ' . $data['email'], 'ERROR');
    sendJsonResponse(['status' => 'error', 'message' => 'Invalid email address'], 400);
}

try {
    // Handle file upload if present
    $resumePath = null;
    $resumeFileName = null;

    if (!empty($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/uploads/resumes/';

        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            if (!mkdir($uploadDir, 0755, true)) {
                throw new Exception("Failed to create upload directory.");
            }
        }

        // Validate file upload
        $file = $_FILES['resume'];
        $allowedTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'text/plain'
        ];
        $allowedExtensions = ['pdf', 'doc', 'docx', 'txt'];
        $maxSize = 5 * 1024 * 1024; // 5MB

        // Check file type - using alternative method for compatibility
        $mimeType = '';
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
        } else {
            // Fallback method using $_FILES['type'] or file extension
            $mimeType = $file['type'] ?? '';
        }

        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        // Validate file type - check extension first, then mime type if available
        if (!in_array($extension, $allowedExtensions)) {
            throw new Exception("Invalid file extension. Only PDF, DOC, DOCX, and TXT files are allowed.");
        }
        
        // Additional mime type check if available
        if (!empty($mimeType) && !in_array($mimeType, $allowedTypes)) {
            throw new Exception("Invalid file type. Only PDF, DOC, DOCX, and TXT files are allowed.");
        }

        if ($file['size'] > $maxSize) {
            throw new Exception("File size exceeds maximum limit of 5MB.");
        }

        // Generate secure filename
        $filename = 'resume_' . uniqid() . '_' . time() . '.' . $extension;
        $resumePath = 'uploads/resumes/' . $filename;
        $fullPath = $uploadDir . $filename;

        if (!move_uploaded_file($file['tmp_name'], $fullPath)) {
            throw new Exception("Failed to save uploaded file.");
        }

        $resumeFileName = $file['name'];
        logData("File uploaded successfully: $filename (original: {$file['name']})", 'INFO');
    }

    // Prepare email
    $to = JOBS_EMAIL;
    $subject = EMAIL_SUBJECT_PREFIX . "New Job Application: " . $data['jobTitle'];

    $message = "
<html>
<head>
    <title>New Job Application</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .content { padding: 20px; }
        .field { margin-bottom: 15px; }
        .label { font-weight: bold; color: #555; }
        .value { margin-left: 10px; }
        .cover-letter { margin-top: 10px; padding: 15px; background-color: #f8f9fa; border-radius: 5px; }
        .resume-info { background-color: #e3f2fd; padding: 10px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class='header'>
        <h2>New Job Application</h2>
        <p>Position: <strong>{$data['jobTitle']}</strong></p>
        <p>Received: " . date('Y-m-d H:i:s') . "</p>
    </div>
    <div class='content'>
        <div class='field'>
            <span class='label'>Applicant:</span>
            <span class='value'>{$data['firstName']} {$data['lastName']}</span>
        </div>
        <div class='field'>
            <span class='label'>Email:</span>
            <span class='value'>{$data['email']}</span>
        </div>
        <div class='field'>
            <span class='label'>Phone:</span>
            <span class='value'>{$data['phone']}</span>
        </div>
        <div class='field'>
            <span class='label'>Experience:</span>
            <span class='value'>{$data['experience']} years</span>
        </div>
        <div class='field'>
            <span class='label'>Availability:</span>
            <span class='value'>{$data['availability']}</span>
        </div>
        <div class='field'>
            <span class='label'>Cover Letter:</span>
            <div class='cover-letter'>
                " . nl2br(htmlspecialchars($data['coverLetter'])) . "
            </div>
        </div>";

    if ($resumePath) {
        $message .= "
        <div class='field'>
            <span class='label'>Resume:</span>
            <div class='resume-info'>
                <strong>File:</strong> " . htmlspecialchars($resumeFileName) . "<br>
                <strong>Server Path:</strong> " . htmlspecialchars($resumePath) . "<br>
                <em>Resume file has been uploaded to the server.</em>
            </div>
        </div>";
    } else {
        $message .= "
        <div class='field'>
            <span class='label'>Resume:</span>
            <span class='value'><em>No resume attached</em></span>
        </div>";
    }

    $message .= "
    </div>
    <hr>
    <p><small>Sent from VAH Care website job application form</small></p>
</body>
</html>
";

    // Email headers
    $headers = [
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=UTF-8',
        // Changed 'From' header to use JOBS_EMAIL
        'From: VAH Care Website <' . JOBS_EMAIL . '>',
        'Reply-To: ' . $data['email'],
        'X-Mailer: PHP/' . phpversion(),
        'X-Priority: 1'
    ];

    // Log email attempt
    logData([
        'to' => $to,
        'subject' => $subject,
        'from' => $data['email'],
        'applicant' => $data['firstName'] . ' ' . $data['lastName'],
        'position' => $data['jobTitle'],
        'resume_uploaded' => !empty($resumePath)
    ], 'INFO');

    // Send email - handle local vs production
    if ($isDevelopment) {
        // Simulate email sending for local testing
        $mailSent = true;
        logData("LOCAL TESTING: Job application email would be sent to $to with subject: $subject", 'INFO');
        logData("LOCAL TESTING: Applicant: {$data['firstName']} {$data['lastName']}, Position: {$data['jobTitle']}", 'INFO');
        logData("LOCAL TESTING: Email content preview: " . substr($message, 0, 200) . "...", 'INFO');
    } else {
        // Real email sending for production
        $mailSent = mail($to, $subject, $message, implode("\r\n", $headers));
    }

    if (!$mailSent) {
        throw new Exception('Mail function failed - please check server mail configuration');
    }

    // Log success
    logData('Job application email sent successfully to ' . $to, 'INFO');

    // Return success response
    sendJsonResponse([
        'status' => 'success',
        'message' => 'Thank you for your application! We will review it and get back to you soon.'
    ]);
} catch (Exception $e) {
    logData("Job application error: " . $e->getMessage(), 'ERROR');
    sendJsonResponse([
        'status' => 'error',
        'message' => $e->getMessage(),
        'debug' => $isDevelopment ? $e->getMessage() : null
    ], 500);
}
